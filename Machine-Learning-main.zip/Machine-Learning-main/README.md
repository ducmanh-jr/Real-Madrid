# Thông báo
  * ...
# Ghi chú
Sinh viên vào xem thông tin **trước 1 ngày** học / kiểm tra / thi
